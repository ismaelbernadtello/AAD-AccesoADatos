﻿using System;
namespace RazorPages.Modelos
{
	public class CursoCuantos //para que sea accesible desde IAlumnoRepositorio
	{
		public Curso Clase { get; set; }
		public int NumAlumnos { get; set; }
        
	}
}

