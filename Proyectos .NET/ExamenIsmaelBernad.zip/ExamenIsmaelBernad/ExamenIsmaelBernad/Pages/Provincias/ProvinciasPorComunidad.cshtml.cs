using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ExamenIsmaelBernad.Pages.Provincias
{
    public class ProvinciasPorComunidadModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
