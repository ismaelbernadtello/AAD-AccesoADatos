﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenIsmaelBernad.Modelos
{
    public enum Comunidad
    {
        Andalucia,
        Aragon,
        Asturias,
        Baleares,
        Canarias,
        Cantabria,
        CastillaLaMancha,
        CastillaLeon,
        Cataluña,
        Extremadura,
        Galicia,
        Madrid,
        Murcia,
        Navarra,
        PaisVasco,
        Rioja,
        Valencia,
    }
}
