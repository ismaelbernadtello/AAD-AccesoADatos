﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenIsmaelBernad.Modelos
{
    public class ComunidadCuantos
    {
        public Comunidad Comunidad { get; set; }
        public int superficieTotal { get; set; }
        public int numHabitantesTotal { get; set; }
        public int numProvinciasTotal { get; set; }

    }
}
